import numpy as np
import wfdb
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt
import os

class ECGDataPreprocessor:
    def __init__(self, data_dir='data/mit-bih-arrhythmia-database-1.0.0'):
        self.data_dir = data_dir
        self.records = []

    def load_mit_bih_records(self, record_ids=None):
        """Load MIT-BIH Arrhythmia records"""
        if record_ids is None:
            # Load first 10 records for demo
            record_ids = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109]

        for record_id in record_ids:
            try:
                record = wfdb.rdrecord(os.path.join(self.data_dir, str(record_id)))
                annotation = wfdb.rdann(os.path.join(self.data_dir, str(record_id)), 'atr')
                self.records.append({
                    'record': record,
                    'annotation': annotation,
                    'record_id': record_id
                })
                print(f"Loaded record {record_id}")
            except Exception as e:
                print(f"Error loading record {record_id}: {e}")

        return self.records

    def apply_bandpass_filter(self, signal, lowcut=0.5, highcut=40.0, fs=360, order=5):
        """Apply bandpass filter to remove noise"""
        nyquist = 0.5 * fs
        low = lowcut / nyquist
        high = highcut / nyquist
        b, a = butter(order, [low, high], btype='band')
        try:
            filtered_signal = filtfilt(b, a, signal)
        except ValueError:
            # For very short signals, standard filtfilt padding fails.
            # Fall back to a simple moving average smoothing.
            window = min(3, len(signal))
            if window <= 0:
                return signal.astype(float)
            kernel = np.ones(window) / window
            filtered_signal = np.convolve(signal, kernel, mode='same')
        return filtered_signal

    def normalize_signal(self, signal):
        """Normalize ECG signal"""
        std = np.std(signal)
        if std == 0:
            return signal - np.mean(signal)
        return (signal - np.mean(signal)) / std

    def preprocess_record(self, record_data):
        """Preprocess a single ECG record"""
        signal = record_data['record'].p_signal[:, 0]  # Use first lead
        fs = record_data['record'].fs

        # Apply bandpass filter
        filtered_signal = self.apply_bandpass_filter(signal, fs=fs)

        # Normalize
        normalized_signal = self.normalize_signal(filtered_signal)

        return {
            'original_signal': signal,
            'filtered_signal': filtered_signal,
            'normalized_signal': normalized_signal,
            'fs': fs,
            'record_id': record_data['record_id']
        }

    def preprocess_all_records(self):
        """Preprocess all loaded records"""
        processed_data = []
        for record_data in self.records:
            processed = self.preprocess_record(record_data)
            processed_data.append(processed)
        return processed_data

    def plot_signal(self, signal, title="ECG Signal"):
        """Plot ECG signal"""
        plt.figure(figsize=(12, 4))
        plt.plot(signal)
        plt.title(title)
        plt.xlabel("Samples")
        plt.ylabel("Amplitude")
        plt.grid(True)
        plt.show()

if __name__ == "__main__":
    preprocessor = ECGDataPreprocessor()
    records = preprocessor.load_mit_bih_records()
    processed_data = preprocessor.preprocess_all_records()

    # Plot example
    if processed_data:
        preprocessor.plot_signal(processed_data[0]['original_signal'], "Original ECG Signal")
        preprocessor.plot_signal(processed_data[0]['filtered_signal'], "Filtered ECG Signal")
        preprocessor.plot_signal(processed_data[0]['normalized_signal'], "Normalized ECG Signal")
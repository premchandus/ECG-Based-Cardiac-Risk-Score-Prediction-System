#!/usr/bin/env python3
"""
Simple test script to validate the ECG project structure
"""

import os
import sys
import importlib.util

def test_file_exists(filepath):
    """Test if file exists"""
    if os.path.exists(filepath):
        print(f"✓ {filepath} exists")
        return True
    else:
        print(f"✗ {filepath} missing")
        return False

def test_module_import(module_name, filepath):
    """Test if module can be imported"""
    try:
        spec = importlib.util.spec_from_file_location(module_name, filepath)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        print(f"✓ {module_name} module structure valid")
        return True
    except Exception as e:
        print(f"✗ {module_name} import failed: {e}")
        return False

def main():
    print("Testing ECG Cardiac Risk Prediction Project Structure")
    print("=" * 60)

    # Test file existence
    files_to_check = [
        'main.py',
        'requirements.txt',
        'README.md',
        'ecg_analysis_demo.ipynb',
        'data_preprocessing.py',
        'qrs_detection.py',
        'feature_extraction.py',
        'model_training.py',
        'risk_prediction.py',
        'explainability.py'
    ]

    print("\n1. Checking file existence:")
    all_files_exist = True
    for file in files_to_check:
        if not test_file_exists(file):
            all_files_exist = False

    # Test module imports (syntax check)
    print("\n2. Checking module syntax:")
    modules_to_test = [
        ('data_preprocessing', 'data_preprocessing.py'),
        ('qrs_detection', 'qrs_detection.py'),
        ('feature_extraction', 'feature_extraction.py'),
        ('model_training', 'model_training.py'),
        ('risk_prediction', 'risk_prediction.py'),
        ('explainability', 'explainability.py'),
        ('main', 'main.py')
    ]

    all_modules_valid = True
    for module_name, filepath in modules_to_test:
        if not test_module_import(module_name, filepath):
            all_modules_valid = False

    # Test directory structure
    print("\n3. Checking directory structure:")
    dirs_to_check = ['data', 'models', 'results', 'notebooks']
    for dir_name in dirs_to_check:
        if os.path.exists(dir_name):
            print(f"✓ {dir_name}/ directory exists")
        else:
            print(f"✗ {dir_name}/ directory missing")
            os.makedirs(dir_name, exist_ok=True)
            print(f"  Created {dir_name}/")

    # Summary
    print("\n" + "=" * 60)
    if all_files_exist and all_modules_valid:
        print("✓ Project structure validation PASSED")
        print("\nNext steps:")
        print("1. Install dependencies: pip install -r requirements.txt")
        print("2. Run training: python main.py (option 2)")
        print("3. Run demo: python main.py (option 5)")
        print("4. Open notebook: jupyter notebook ecg_analysis_demo.ipynb")
    else:
        print("✗ Project structure validation FAILED")
        print("Please check the missing files/modules above")

    print("\nProject ready for ECG-based cardiac risk prediction!")

if __name__ == "__main__":
    main()
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class ECGExplainability:
    def __init__(self, model, feature_columns):
        self.model = model
        self.feature_columns = feature_columns
        self.scaler = StandardScaler()
        self.explainer = None

    def initialize_explainer(self, background_data=None):
        """Initialize SHAP explainer"""
        if background_data is None:
            # Create a small background dataset for kernel explainer
            background_data = np.random.randn(100, len(self.feature_columns))

        try:
            if hasattr(self.model, 'predict_proba'):
                self.explainer = shap.TreeExplainer(self.model)
            else:
                self.explainer = shap.KernelExplainer(self.model.predict, background_data)
        except:
            # Fallback to kernel explainer
            self.explainer = shap.KernelExplainer(self.model.predict, background_data)

    def explain_prediction(self, features, max_evals=1000):
        """Explain a single prediction"""
        if self.explainer is None:
            self.initialize_explainer()

        if isinstance(features, pd.DataFrame):
            features = features.values

        # Ensure features is 2D
        if features.ndim == 1:
            features = features.reshape(1, -1)

        try:
            if hasattr(self.explainer, 'shap_values'):
                # Tree explainer
                shap_values = self.explainer.shap_values(features)
                if isinstance(shap_values, list):
                    # Multi-class case
                    shap_values = shap_values[0]  # Take first class
            else:
                # Kernel explainer
                shap_values = self.explainer.shap_values(features, max_evals=max_evals)

            return shap_values[0] if len(shap_values.shape) > 1 else shap_values
        except Exception as e:
            print(f"Error in SHAP explanation: {e}")
            return None

    def plot_feature_importance(self, features_df, max_features=15):
        """Plot global feature importance"""
        if self.explainer is None:
            self.initialize_explainer()

        try:
            plt.figure(figsize=(10, 8))

            if hasattr(self.explainer, 'shap_values'):
                # For tree models
                shap.summary_plot(self.explainer.shap_values(features_df.values),
                                features_df, max_display=max_features, show=False)
            else:
                # For kernel explainer, compute shap values for a sample
                sample_size = min(100, len(features_df))
                sample_data = features_df.sample(sample_size, random_state=42)
                shap_values = self.explainer.shap_values(sample_data.values)
                shap.summary_plot(shap_values, sample_data, max_display=max_features, show=False)

            plt.title('SHAP Feature Importance')
            plt.tight_layout()
            plt.show()
        except Exception as e:
            print(f"Error plotting feature importance: {e}")

    def plot_waterfall(self, features, feature_names=None):
        """Plot waterfall plot for single prediction"""
        if feature_names is None:
            feature_names = self.feature_columns

        shap_values = self.explain_prediction(features)

        if shap_values is None:
            return

        try:
            plt.figure(figsize=(10, 6))

            # Create waterfall plot manually
            base_value = self.explainer.expected_value
            if isinstance(base_value, np.ndarray):
                base_value = base_value[0]

            shap_df = pd.DataFrame({
                'feature': feature_names,
                'shap_value': shap_values
            }).sort_values('shap_value', key=abs, ascending=False)

            cumulative = base_value
            bars = []

            for _, row in shap_df.iterrows():
                bars.append({
                    'feature': row['feature'],
                    'start': cumulative,
                    'shap': row['shap_value'],
                    'end': cumulative + row['shap_value']
                })
                cumulative += row['shap_value']

            # Plot
            fig, ax = plt.subplots(figsize=(12, 8))

            for i, bar in enumerate(bars[:10]):  # Top 10 features
                color = 'red' if bar['shap'] > 0 else 'blue'
                ax.barh(i, bar['shap'], left=bar['start'], color=color, alpha=0.7)
                ax.text(bar['start'] + bar['shap']/2, i, f"{bar['feature']}\n{bar['shap']:.3f}",
                       ha='center', va='center', fontsize=8)

            ax.axvline(base_value, color='black', linestyle='--', alpha=0.5, label=f'Base value: {base_value:.3f}')
            ax.set_yticks(range(len(bars[:10])))
            ax.set_yticklabels([bar['feature'] for bar in bars[:10]])
            ax.set_xlabel('SHAP Value')
            ax.set_title('SHAP Waterfall Plot')
            ax.legend()
            plt.tight_layout()
            plt.show()

        except Exception as e:
            print(f"Error plotting waterfall: {e}")

    def plot_force_plot(self, features, feature_names=None):
        """Plot force plot for single prediction"""
        if feature_names is None:
            feature_names = self.feature_columns

        shap_values = self.explain_prediction(features)

        if shap_values is None:
            return

        try:
            plt.figure(figsize=(12, 3))

            base_value = self.explainer.expected_value
            if isinstance(base_value, np.ndarray):
                base_value = base_value[0]

            # Sort features by absolute SHAP value
            shap_df = pd.DataFrame({
                'feature': feature_names,
                'shap_value': shap_values
            })
            shap_df = shap_df.sort_values('shap_value', key=abs, ascending=False)

            # Plot force plot
            cumulative = base_value
            colors = ['red' if x > 0 else 'blue' for x in shap_df['shap_value']]

            plt.barh(0, base_value, color='gray', alpha=0.3, label='Base value')

            for i, (_, row) in enumerate(shap_df.iterrows()):
                plt.barh(0, row['shap_value'], left=cumulative,
                        color=colors[i], alpha=0.7, label=row['feature'] if i < 5 else "")
                cumulative += row['shap_value']

            plt.axvline(cumulative, color='black', linewidth=2, label='Final prediction')
            plt.yticks([])
            plt.xlabel('Prediction Value')
            plt.title('SHAP Force Plot')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.tight_layout()
            plt.show()

        except Exception as e:
            print(f"Error plotting force plot: {e}")

    def get_feature_contributions(self, features, feature_names=None, top_n=5):
        """Get top contributing features for a prediction"""
        if feature_names is None:
            feature_names = self.feature_columns

        shap_values = self.explain_prediction(features)

        if shap_values is None:
            return []

        shap_df = pd.DataFrame({
            'feature': feature_names,
            'shap_value': shap_values,
            'abs_shap': np.abs(shap_values)
        }).sort_values('abs_shap', ascending=False)

        contributions = []
        for _, row in shap_df.head(top_n).iterrows():
            contributions.append({
                'feature': row['feature'],
                'contribution': row['shap_value'],
                'direction': 'increases risk' if row['shap_value'] > 0 else 'decreases risk'
            })

        return contributions

    def explain_model_behavior(self, features_df, target_class=None):
        """Provide overall model behavior explanation"""
        if self.explainer is None:
            self.initialize_explainer()

        try:
            # Global explanation
            self.plot_feature_importance(features_df)

            # Class-specific analysis if applicable
            if hasattr(self.model, 'classes_') and len(self.model.classes_) > 2:
                print(f"Model predicts {len(self.model.classes_)} classes: {self.model.classes_}")
                if target_class is not None:
                    print(f"Focusing on class: {target_class}")
            else:
                print("Binary or regression model")

        except Exception as e:
            print(f"Error in model behavior explanation: {e}")

if __name__ == "__main__":
    # Example usage
    from model_training import CardiacRiskModel
    import numpy as np
    import pandas as pd

    # Load or create a model
    try:
        risk_model = CardiacRiskModel()
        risk_model.load_model('cardiac_risk_model.pkl')
    except:
        print("Model not found. Please train the model first.")
        exit()

    # Create sample features
    sample_features = pd.DataFrame({
        'heart_rate': [85],
        'rmssd': [25],
        'pnn50': [8],
        'lf_hf_ratio': [1.8],
        'qrs_amplitude': [0.9],
        'mean_rr': [0.75],
        'std_rr': [0.04]
    })

    # Initialize explainability
    explainer = ECGExplainability(risk_model.model, risk_model.feature_columns)

    # Explain single prediction
    contributions = explainer.get_feature_contributions(sample_features.values[0])
    print("Top contributing features:")
    for contrib in contributions:
        print(f"- {contrib['feature']}: {contrib['contribution']:.3f} ({contrib['direction']})")

    # Plot explanations
    explainer.plot_waterfall(sample_features.values[0])
    explainer.plot_force_plot(sample_features.values[0])
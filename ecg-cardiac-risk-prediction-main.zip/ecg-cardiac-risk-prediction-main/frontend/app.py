import base64
import io
import os
import sys
import logging
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from flask import Flask, render_template, request

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Ensure root package imports work from frontend directory
ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

from risk_prediction import CardiacRiskPredictor
from model_training import CardiacRiskModel

MODEL_PATH = ROOT_DIR / 'models' / 'cardiac_risk_model.pkl'

# Configuration constants
MIN_SIGNAL_LENGTH = 5
MAX_SIGNAL_LENGTH = 10000
RECOMMENDED_SIGNAL_LENGTH = 360  # 1 second at 360 Hz sampling rate

app = Flask(__name__, template_folder='templates', static_folder='static')


def ensure_model():
    if MODEL_PATH.exists():
        logger.info(f"Using existing model: {MODEL_PATH}")
        return

    logger.info('Training synthetic model for frontend use...')
    np.random.seed(42)
    n_samples = 2000
    features = {
        'heart_rate': np.random.normal(75, 15, n_samples),
        'rmssd': np.random.normal(30, 10, n_samples),
        'pnn50': np.random.normal(10, 5, n_samples),
        'lf_hf_ratio': np.random.normal(1.5, 0.5, n_samples),
        'qrs_amplitude': np.random.normal(1.0, 0.3, n_samples),
        'mean_rr': np.random.normal(0.8, 0.1, n_samples),
        'std_rr': np.random.normal(0.05, 0.02, n_samples),
        'qrs_energy': np.random.normal(100, 30, n_samples),
        'qrs_skewness': np.random.normal(0, 0.5, n_samples),
        'qrs_kurtosis': np.random.normal(0, 1, n_samples)
    }

    features_df = __import__('pandas').DataFrame(features)
    risk_model = CardiacRiskModel(model_type='random_forest')
    X, y = risk_model.prepare_data(features_df)
    risk_model.train_model(X, y)
    risk_model.save_model(str(MODEL_PATH))
    logger.info(f"Model trained and saved: {MODEL_PATH}")


def load_predictor():
    ensure_model()
    return CardiacRiskPredictor(model_path=str(MODEL_PATH))


def generate_sample_ecg(signal_type='normal', duration_sec=10, fs=360):
    t = np.linspace(0, duration_sec, duration_sec * fs)
    if signal_type == 'abnormal':
        signal = (np.sin(2 * np.pi * 2.0 * t) +
                  0.5 * np.sin(2 * np.pi * 0.3 * t) +
                  0.1 * np.random.randn(len(t)))
    else:
        signal = (np.sin(2 * np.pi * 1.25 * t) +
                  0.3 * np.sin(2 * np.pi * 0.5 * t) +
                  0.05 * np.random.randn(len(t)))
    return signal


def create_signal_plot(signal, sampling_rate=360):
    time = np.arange(len(signal)) / sampling_rate
    fig, ax = plt.subplots(figsize=(10, 3))
    ax.plot(time, signal, color='#1f77b4', linewidth=1.5)
    ax.set_title('ECG Signal Visualization')
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Amplitude (mV)')
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    buffer = io.BytesIO()
    fig.savefig(buffer, format='png', dpi=100)
    plt.close(fig)
    buffer.seek(0)
    return base64.b64encode(buffer.read()).decode('utf-8')


def parse_custom_signal(raw_text):
    """Parse custom ECG signal values with comprehensive validation and error reporting."""
    if not raw_text or not raw_text.strip():
        return None, "Empty input"

    text = raw_text.replace(',', ' ').replace(';', ' ').replace('\n', ' ').strip()
    
    try:
        # Split and convert to float, filtering empty strings
        values = [float(v.strip()) for v in text.split() if v.strip()]
        
        if not values:
            return None, "No numeric values found in input"
        
        if len(values) < MIN_SIGNAL_LENGTH:
            return None, f"Signal too short: {len(values)} samples provided, minimum {MIN_SIGNAL_LENGTH} required"
        
        if len(values) > MAX_SIGNAL_LENGTH:
            return None, f"Signal too long: {len(values)} samples provided, maximum {MAX_SIGNAL_LENGTH} allowed"
        
        signal = np.array(values, dtype=np.float32)
        
        # Validate for reasonable ECG ranges
        if np.any(np.isnan(signal)) or np.any(np.isinf(signal)):
            return None, "Signal contains invalid values (NaN or infinity)"
        
        logger.info(f"Successfully parsed custom signal: {len(values)} samples")
        return signal, None
        
    except ValueError as e:
        logger.warning(f"Parse error: {str(e)}")
        return None, f"Invalid numeric value in input. Please ensure all values are numbers separated by comma, space, semicolon, or newline"
    except Exception as e:
        logger.error(f"Unexpected parse error: {str(e)}")
        return None, f"Unexpected error parsing input: {str(e)}"


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html', 
                         min_samples=MIN_SIGNAL_LENGTH,
                         recommended_samples=RECOMMENDED_SIGNAL_LENGTH)


@app.route('/predict', methods=['POST'])
def predict():
    try:
        sampling_rate = 360
        custom_signal = request.form.get('custom_signal', '').strip()
        sample_type = request.form.get('sample_type', 'normal')

        signal = None
        error = None
        used_custom = False

        # Try to parse custom signal if provided
        if custom_signal:
            signal, parse_error = parse_custom_signal(custom_signal)
            if signal is not None:
                used_custom = True
                logger.info(f"Using custom ECG signal: {len(signal)} samples")
            else:
                error = parse_error
                logger.warning(f"Custom signal parse failed: {parse_error}")

        # Fall back to sample signal if custom parsing failed or wasn't provided
        if signal is None:
            signal = generate_sample_ecg(sample_type)
            if not custom_signal:
                # No custom signal was provided, this is normal
                pass
            # Custom signal was provided but failed - error is already set

        predictor = load_predictor()
        result, predict_error = predictor.predict_from_signal(signal, sampling_rate=sampling_rate)

        if predict_error:
            logger.error(f"Prediction error: {predict_error}")
            return render_template('result.html', error=f"Prediction failed: {predict_error}")

        plot_data = create_signal_plot(signal, sampling_rate)

        return render_template(
            'result.html',
            error=error,
            result=result,
            plot_data=plot_data,
            sample_type=sample_type,
            custom_signal=custom_signal,
            signal_length=len(signal),
            used_custom=used_custom
        )
        
    except Exception as e:
        logger.error(f"Unexpected error in predict: {str(e)}", exc_info=True)
        return render_template('result.html', error=f"Server error: {str(e)}")


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5001))
    logger.info(f"Starting Flask app on port {port}")
    app.run(host='127.0.0.1', port=port, debug=True)

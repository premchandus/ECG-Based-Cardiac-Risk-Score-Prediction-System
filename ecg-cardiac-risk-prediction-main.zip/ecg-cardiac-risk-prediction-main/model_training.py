import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

class CardiacRiskModel:
    def __init__(self, model_type='random_forest'):
        self.model_type = model_type
        self.model = None
        self.label_encoder = LabelEncoder()
        self.feature_columns = None

    def create_synthetic_labels(self, features_df):
        """Create synthetic risk labels based on features"""
        # Simple rule-based labeling for demonstration
        # In real scenario, this would be based on clinical annotations

        risk_scores = []

        for idx, row in features_df.iterrows():
            score = 0

            # Heart rate criteria
            if pd.notna(row.get('heart_rate', np.nan)):
                hr = row['heart_rate']
                if hr < 60 or hr > 100:
                    score += 1

            # HRV criteria
            if pd.notna(row.get('rmssd', np.nan)):
                if row['rmssd'] < 20:
                    score += 1

            if pd.notna(row.get('pnn50', np.nan)):
                if row['pnn50'] < 5:
                    score += 1

            # Frequency domain
            if pd.notna(row.get('lf_hf_ratio', np.nan)):
                if row['lf_hf_ratio'] > 2.5 or row['lf_hf_ratio'] < 0.5:
                    score += 1

            # Morphological
            if pd.notna(row.get('qrs_amplitude', np.nan)):
                if row['qrs_amplitude'] < 0.5:
                    score += 1

            risk_scores.append(score)

        # Convert scores to risk categories
        risk_labels = []
        for score in risk_scores:
            if score <= 1:
                risk_labels.append('Low')
            elif score <= 3:
                risk_labels.append('Medium')
            else:
                risk_labels.append('High')

        return risk_labels

    def prepare_data(self, features_df, labels=None):
        """Prepare data for training"""
        # Handle missing values
        features_df = features_df.fillna(features_df.mean())

        if labels is None:
            labels = self.create_synthetic_labels(features_df)

        # Encode labels
        encoded_labels = self.label_encoder.fit_transform(labels)

        self.feature_columns = features_df.columns.tolist()

        return features_df.values, encoded_labels

    def train_model(self, X, y, test_size=0.2, random_state=42):
        """Train the machine learning model"""
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )

        if self.model_type == 'random_forest':
            self.model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=random_state,
                class_weight='balanced'
            )
        elif self.model_type == 'svm':
            self.model = SVC(
                kernel='rbf',
                C=1.0,
                gamma='scale',
                class_weight='balanced',
                probability=True,
                random_state=random_state
            )
        else:
            raise ValueError(f"Unsupported model type: {self.model_type}")

        # Train the model
        self.model.fit(X_train, y_train)

        # Evaluate
        train_score = self.model.score(X_train, y_train)
        test_score = self.model.score(X_test, y_test)

        print(f"Training accuracy: {train_score:.4f}")
        print(f"Testing accuracy: {test_score:.4f}")

        # Cross-validation
        cv_scores = cross_val_score(self.model, X_train, y_train, cv=5)
        print(f"Cross-validation accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")

        return X_train, X_test, y_train, y_test

    def evaluate_model(self, X_test, y_test):
        """Evaluate model performance"""
        y_pred = self.model.predict(X_test)

        print("\nClassification Report:")
        print(classification_report(y_test, y_pred, target_names=self.label_encoder.classes_))

        # Confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                    xticklabels=self.label_encoder.classes_,
                    yticklabels=self.label_encoder.classes_)
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.show()

        return cm

    def predict_risk(self, features):
        """Predict cardiac risk for new data"""
        if isinstance(features, pd.DataFrame):
            # Handle missing values
            features = features.fillna(features.mean())

            # Align to the model's expected feature columns
            if self.feature_columns is not None:
                missing_cols = [c for c in self.feature_columns if c not in features.columns]
                for col in missing_cols:
                    features[col] = 0
                features = features[self.feature_columns]

            features = features.values

        prediction = self.model.predict(features)
        probabilities = self.model.predict_proba(features)

        risk_labels = self.label_encoder.inverse_transform(prediction)

        return risk_labels, probabilities

    def get_feature_importance(self):
        """Get feature importance (for Random Forest)"""
        if self.model_type == 'random_forest' and hasattr(self.model, 'feature_importances_'):
            importance_df = pd.DataFrame({
                'feature': self.feature_columns,
                'importance': self.model.feature_importances_
            }).sort_values('importance', ascending=False)

            plt.figure(figsize=(10, 6))
            sns.barplot(data=importance_df.head(15), x='importance', y='feature')
            plt.title('Top 15 Feature Importances')
            plt.show()

            return importance_df
        else:
            print("Feature importance not available for this model type")
            return None

    def save_model(self, filepath):
        """Save the trained model"""
        model_data = {
            'model': self.model,
            'label_encoder': self.label_encoder,
            'feature_columns': self.feature_columns,
            'model_type': self.model_type
        }
        joblib.dump(model_data, filepath)
        print(f"Model saved to {filepath}")

    def load_model(self, filepath):
        """Load a trained model"""
        model_data = joblib.load(filepath)
        self.model = model_data['model']
        self.label_encoder = model_data['label_encoder']
        self.feature_columns = model_data['feature_columns']
        self.model_type = model_data['model_type']
        print(f"Model loaded from {filepath}")

if __name__ == "__main__":
    # Example usage with synthetic data
    np.random.seed(42)

    # Create synthetic features
    n_samples = 1000
    features = {
        'heart_rate': np.random.normal(75, 15, n_samples),
        'rmssd': np.random.normal(30, 10, n_samples),
        'pnn50': np.random.normal(10, 5, n_samples),
        'lf_hf_ratio': np.random.normal(1.5, 0.5, n_samples),
        'qrs_amplitude': np.random.normal(1.0, 0.3, n_samples),
        'mean_rr': np.random.normal(0.8, 0.1, n_samples),
        'std_rr': np.random.normal(0.05, 0.02, n_samples)
    }

    features_df = pd.DataFrame(features)

    # Train model
    risk_model = CardiacRiskModel(model_type='random_forest')
    X, y = risk_model.prepare_data(features_df)
    X_train, X_test, y_train, y_test = risk_model.train_model(X, y)

    # Evaluate
    risk_model.evaluate_model(X_test, y_test)

    # Feature importance
    risk_model.get_feature_importance()

    # Save model
    risk_model.save_model('cardiac_risk_model.pkl')
# ECG-Based Cardiac Risk Score Prediction System

A comprehensive machine learning system for analyzing ECG signals and predicting cardiac risk levels using explainable artificial intelligence techniques.

## Overview

This project implements an automated ECG-based cardiac risk prediction system that processes raw ECG signals to detect important waveform components, extract clinically relevant features, and predict cardiac risk scores. The system uses machine learning techniques with explainable AI to provide transparent and trustworthy predictions for clinical use.

## Features

- **ECG Signal Preprocessing**: Noise removal, baseline correction, and normalization
- **QRS Complex Detection**: Accurate R-peak identification using advanced signal processing
- **Feature Extraction**: Comprehensive time-domain and frequency-domain heart rate variability (HRV) features
- **Machine Learning Models**: Random Forest and SVM classifiers for risk prediction
- **Risk Stratification**: Classification into Low, Medium, and High cardiac risk categories
- **Explainable AI**: SHAP-based model interpretation for clinical transparency
- **Visualization**: Comprehensive plots for signal analysis and model explanations

## Architecture

```
ECG Dataset → Signal Preprocessing → QRS Detection → Feature Extraction → ML Model → Risk Score → XAI Interpretation
```

## Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager

### Setup

1. Clone or download the project:
   ```bash
   cd ecg-cardiac-risk-prediction
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. (Optional) Download MIT-BIH Arrhythmia Dataset:
   - Visit: https://physionet.org/content/mitdb/1.0.0/
   - Download and extract to `data/mit-bih-arrhythmia-database-1.0.0/`

## Usage

### Quick Start

Run the main application:
```bash
python main.py
```

This will present a menu with the following options:
1. Setup project directories
2. Train cardiac risk model
3. Demonstrate risk prediction
4. Demonstrate explainability
5. Run full pipeline
6. Download dataset information
7. Exit

### Interactive Demo

Launch the Jupyter notebook:
```bash
jupyter notebook ecg_analysis_demo.ipynb
```

The notebook provides a step-by-step demonstration of:
- ECG signal preprocessing
- QRS complex detection
- Feature extraction
- Model training and evaluation
- Risk prediction
- Explainable AI interpretation

### Web Frontend

A Flask-based frontend is available in `frontend/app.py`.

Run the web app:
```bash
python3 frontend/app.py
```

If port `5000` is blocked or returns a 403, use port `5001` instead:
```bash
PORT=5001 python3 frontend/app.py
```

If your shell does not have a `python` command, use the system Python explicitly:
```bash
PORT=5001 /usr/bin/python3 frontend/app.py
```

Open the browser at:
```bash
http://127.0.0.1:5001
```

If `localhost` resolves incorrectly, use `127.0.0.1` directly to avoid local service conflicts.

You can choose a built-in ECG sample or paste custom ECG values to evaluate cardiac risk.

### Python API Usage

```python
from risk_prediction import CardiacRiskPredictor
import numpy as np

# Load trained model
predictor = CardiacRiskPredictor(model_path='models/cardiac_risk_model.pkl')

# Create sample ECG signal
t = np.linspace(0, 10, 3600)
signal = np.sin(2 * np.pi * 1.25 * t) + 0.1 * np.random.randn(3600)

# Predict cardiac risk
result, error = predictor.predict_from_signal(signal, sampling_rate=360)

if result:
    print(f"Risk Score: {result['risk_score']}")
    print(f"Confidence: {result['confidence']:.2%}")
    print(f"Heart Rate: {np.mean(result['qrs_info']['heart_rate']):.1f} BPM")
```

## Project Structure

```
ecg-cardiac-risk-prediction/
├── main.py                     # Main application script
├── ecg_analysis_demo.ipynb     # Jupyter notebook demo
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── data_preprocessing.py       # ECG signal preprocessing
├── qrs_detection.py           # QRS complex detection
├── feature_extraction.py      # Feature extraction module
├── model_training.py          # ML model training
├── risk_prediction.py         # Risk prediction system
├── explainability.py          # XAI interpretation
├── data/                      # Dataset directory
├── models/                    # Trained models
└── results/                   # Output results
```

## Key Components

### 1. Data Preprocessing (`data_preprocessing.py`)
- Bandpass filtering (0.5-40 Hz)
- Baseline wander removal
- Signal normalization
- Support for MIT-BIH dataset

### 2. QRS Detection (`qrs_detection.py`)
- R-peak identification using biosppy
- RR interval calculation
- Heart rate computation
- Detection validation metrics

### 3. Feature Extraction (`feature_extraction.py`)
- **Time-domain HRV**: RMSSD, pNN50, mean RR, SDNN
- **Frequency-domain HRV**: VLF, LF, HF power, LF/HF ratio
- **Morphological features**: QRS amplitude, energy, skewness, kurtosis

### 4. Machine Learning (`model_training.py`)
- Random Forest and SVM models
- Cross-validation evaluation
- Feature importance analysis
- Model serialization

### 5. Risk Prediction (`risk_prediction.py`)
- End-to-end prediction pipeline
- Risk score interpretation
- Clinical recommendations
- Comprehensive visualization

### 6. Explainability (`explainability.py`)
- SHAP-based feature attribution
- Waterfall and force plots
- Global feature importance
- Clinical factor identification

## Clinical Risk Categories

- **Low Risk**: Regular monitoring recommended
- **Medium Risk**: Consult healthcare provider for evaluation
- **High Risk**: Immediate medical attention recommended

## Performance Metrics

The system demonstrates:
- High accuracy in QRS detection
- Robust feature extraction
- Good classification performance on test data
- Interpretable model decisions

## Dependencies

- numpy: Numerical computing
- pandas: Data manipulation
- scipy: Signal processing
- scikit-learn: Machine learning
- matplotlib: Visualization
- seaborn: Statistical plots
- wfdb: ECG database access
- biosppy: ECG signal processing
- shap: Explainable AI
- jupyter: Interactive notebooks

## Future Enhancements

- **Multi-lead Analysis**: 12-lead ECG processing
- **Deep Learning**: CNN and LSTM models
- **Real-time Processing**: Wearable device integration
- **Clinical Validation**: Large-scale clinical trials
- **Multi-modal Fusion**: ECG + clinical parameters
- **Web Deployment**: Flask/Django web application
- **Frontend**: New Flask web interface available in `frontend/app.py`

## Dataset

The system is designed to work with the MIT-BIH Arrhythmia Database, the gold standard for ECG analysis research. The dataset contains:

- 48 half-hour ECG recordings
- 47 patients with various arrhythmias
- Annotated beat classifications
- Standard sampling rate of 360 Hz

## Ethical Considerations

- **Clinical Validation**: Requires extensive clinical testing before medical use
- **Bias Assessment**: Regular evaluation for demographic and clinical biases
- **Transparency**: All model decisions should be explainable to clinicians
- **Privacy**: ECG data handling must comply with HIPAA and GDPR
- **Limitations**: Clear communication of system limitations and uncertainties

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is for educational and research purposes. Please consult with medical professionals before using in clinical settings.

## Citation

If you use this code in your research, please cite:

```
ECG-Based Cardiac Risk Score Prediction System
Automated analysis of ECG signals for cardiac risk assessment
```

## Contact

For questions or collaborations, please open an issue on the project repository.
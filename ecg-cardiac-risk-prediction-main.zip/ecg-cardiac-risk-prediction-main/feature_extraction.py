import numpy as np
from scipy import stats
from scipy.signal import welch
import pandas as pd

class ECGFeatureExtractor:
    def __init__(self):
        pass

    def extract_time_domain_hrv(self, rr_intervals):
        """Extract time-domain HRV features"""
        if len(rr_intervals) < 2:
            # With very few RR intervals, provide defaults based on heart rate
            heart_rate = 60.0 / np.mean(rr_intervals) if len(rr_intervals) > 0 else 75.0
            mean_rr = 60.0 / heart_rate  # Convert BPM to RR interval in seconds
            return {
                'mean_rr': mean_rr,
                'std_rr': 0.0,  # No variability with single interval
                'rmssd': 0.0,   # No successive differences
                'pnn50': 0.0    # No successive intervals
            }

        mean_rr = np.mean(rr_intervals)
        std_rr = np.std(rr_intervals, ddof=1)

        # RMSSD (Root Mean Square of Successive Differences)
        diff_rr = np.diff(rr_intervals)
        rmssd = np.sqrt(np.mean(diff_rr ** 2))

        # pNN50 (percentage of successive RR intervals that differ by more than 50ms)
        nn50 = np.sum(np.abs(diff_rr) > 0.05)
        pnn50 = (nn50 / len(diff_rr)) * 100 if len(diff_rr) > 0 else 0

        return {
            'mean_rr': mean_rr,
            'std_rr': std_rr,
            'rmssd': rmssd,
            'pnn50': pnn50
        }

    def extract_frequency_domain_hrv(self, rr_intervals, sampling_rate=4):
        """Extract frequency-domain HRV features"""
        if len(rr_intervals) < 3:
            # Not enough data for frequency analysis, return defaults
            return {
                'vlf_power': 0.0,
                'lf_power': 0.0,
                'hf_power': 0.0,
                'lf_hf_ratio': 1.0,  # Default balanced ratio
                'total_power': 0.0
            }

        # Interpolate RR intervals to create evenly sampled signal
        rr_times = np.cumsum(rr_intervals)
        rr_times -= rr_times[0]  # Start from 0

        # Create evenly sampled time series
        t_interp = np.arange(0, rr_times[-1], 1/sampling_rate)
        rr_interp = np.interp(t_interp, rr_times, rr_intervals)

        # Remove linear trend
        rr_detrended = rr_interp - np.polyval(np.polyfit(t_interp, rr_interp, 1), t_interp)

        # Compute power spectral density
        freqs, psd = welch(rr_detrended, fs=sampling_rate, nperseg=min(256, len(rr_detrended)))

        # Define frequency bands
        vlf_mask = (freqs >= 0.0033) & (freqs < 0.04)
        lf_mask = (freqs >= 0.04) & (freqs < 0.15)
        hf_mask = (freqs >= 0.15) & (freqs < 0.4)

        vlf_power = np.trapz(psd[vlf_mask], freqs[vlf_mask]) if np.any(vlf_mask) else 0
        lf_power = np.trapz(psd[lf_mask], freqs[lf_mask]) if np.any(lf_mask) else 0
        hf_power = np.trapz(psd[hf_mask], freqs[hf_mask]) if np.any(hf_mask) else 0

        total_power = vlf_power + lf_power + hf_power
        lf_hf_ratio = lf_power / hf_power if hf_power > 0 else 1.0  # Default to 1.0 instead of NaN

        return {
            'vlf_power': vlf_power,
            'lf_power': lf_power,
            'hf_power': hf_power,
            'lf_hf_ratio': lf_hf_ratio,
            'total_power': total_power
        }

    def extract_morphological_features(self, templates):
        """Extract morphological features from QRS templates"""
        if templates is None or len(templates) == 0:
            # Return default/placeholder values when no templates available
            return {
                'qrs_amplitude': 0.5,  # Default amplitude
                'qrs_duration': 30,    # Default duration in samples
                'r_peak_amplitude': 0.3,  # Default R-peak amplitude
                'qrs_area': 5.0       # Default area
            }

        # Average template
        avg_template = np.mean(templates, axis=0)

        features = {}

        # Basic morphological features
        features['qrs_amplitude'] = np.max(avg_template) - np.min(avg_template)
        features['qrs_duration'] = len(avg_template)  # In samples

        # Peak characteristics
        max_idx = np.argmax(avg_template)
        min_idx = np.argmin(avg_template)
        features['r_peak_amplitude'] = avg_template[max_idx]
        features['q_peak_amplitude'] = avg_template[min_idx] if min_idx < max_idx else np.min(avg_template[:max_idx])
        features['s_peak_amplitude'] = np.min(avg_template[max_idx:]) if max_idx < len(avg_template) else np.min(avg_template[max_idx:])

        # Wavelet-like features (simple approximation)
        features['qrs_energy'] = np.sum(avg_template ** 2)
        features['qrs_skewness'] = stats.skew(avg_template)
        features['qrs_kurtosis'] = stats.kurtosis(avg_template)

        return features

    def extract_all_features(self, rr_intervals, templates, sampling_rate=360):
        """Extract all ECG features"""
        features = {}

        # Heart rate features
        if len(rr_intervals) > 0:
            features['heart_rate'] = 60 / np.mean(rr_intervals)
            features['heart_rate_std'] = 60 * np.std(rr_intervals) / (np.mean(rr_intervals) ** 2)

        # Time-domain HRV
        time_hrv = self.extract_time_domain_hrv(rr_intervals)
        features.update(time_hrv)

        # Frequency-domain HRV
        freq_hrv = self.extract_frequency_domain_hrv(rr_intervals)
        features.update(freq_hrv)

        # Morphological features
        morph_features = self.extract_morphological_features(templates)
        features.update(morph_features)

        return features

    def create_feature_dataframe(self, feature_list):
        """Create a pandas DataFrame from feature list"""
        return pd.DataFrame(feature_list)

    def normalize_features(self, features_df):
        """Normalize features using z-score"""
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        normalized = scaler.fit_transform(features_df)
        return pd.DataFrame(normalized, columns=features_df.columns), scaler

if __name__ == "__main__":
    # Example usage
    extractor = ECGFeatureExtractor()

    # Dummy RR intervals (in seconds)
    rr_intervals = np.random.normal(0.8, 0.1, 100)

    # Dummy templates
    templates = np.random.randn(10, 100)

    features = extractor.extract_all_features(rr_intervals, templates)
    print("Extracted features:")
    for key, value in features.items():
        print(f"{key}: {value:.4f}")
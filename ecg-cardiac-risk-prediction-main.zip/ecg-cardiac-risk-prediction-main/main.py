#!/usr/bin/env python3
"""
ECG-Based Cardiac Risk Score Prediction System
Main application script
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# Import local modules
from data_preprocessing import ECGDataPreprocessor
from qrs_detection import QRSDetector
from feature_extraction import ECGFeatureExtractor
from model_training import CardiacRiskModel
from risk_prediction import CardiacRiskPredictor
from explainability import ECGExplainability

def setup_project():
    """Setup project directories and check dependencies"""
    print("Setting up ECG Cardiac Risk Prediction Project...")

    # Create necessary directories
    dirs = ['data', 'models', 'results', 'notebooks']
    for dir_name in dirs:
        Path(dir_name).mkdir(exist_ok=True)
        print(f"Created directory: {dir_name}")

    print("Project setup complete!\n")

def download_mit_bih_data():
    """Download MIT-BIH Arrhythmia dataset"""
    print("Note: MIT-BIH Arrhythmia dataset needs to be downloaded manually.")
    print("Please download from: https://physionet.org/content/mitdb/1.0.0/")
    print("Extract to: data/mit-bih-arrhythmia-database-1.0.0/")
    print("Or use the wfdb library to download programmatically.\n")

def train_model_pipeline():
    """Complete model training pipeline"""
    print("Starting model training pipeline...")

    # Create synthetic training data for demonstration
    print("Creating synthetic training data...")
    np.random.seed(42)
    n_samples = 2000

    # Generate realistic ECG features
    features = {
        'heart_rate': np.random.normal(75, 15, n_samples),
        'rmssd': np.random.normal(30, 10, n_samples),
        'pnn50': np.random.normal(10, 5, n_samples),
        'lf_hf_ratio': np.random.normal(1.5, 0.5, n_samples),
        'qrs_amplitude': np.random.normal(1.0, 0.3, n_samples),
        'mean_rr': np.random.normal(0.8, 0.1, n_samples),
        'std_rr': np.random.normal(0.05, 0.02, n_samples),
        'qrs_energy': np.random.normal(100, 30, n_samples),
        'qrs_skewness': np.random.normal(0, 0.5, n_samples),
        'qrs_kurtosis': np.random.normal(0, 1, n_samples)
    }

    features_df = pd.DataFrame(features)

    # Train model
    print("Training cardiac risk model...")
    risk_model = CardiacRiskModel(model_type='random_forest')
    X, y = risk_model.prepare_data(features_df)
    X_train, X_test, y_train, y_test = risk_model.train_model(X, y)

    # Evaluate model
    print("Evaluating model...")
    risk_model.evaluate_model(X_test, y_test)

    # Feature importance
    print("Analyzing feature importance...")
    importance_df = risk_model.get_feature_importance()

    # Save model
    model_path = 'models/cardiac_risk_model.pkl'
    risk_model.save_model(model_path)
    print(f"Model saved to {model_path}")

    return risk_model

def demonstrate_prediction():
    """Demonstrate risk prediction on sample data"""
    print("\nDemonstrating risk prediction...")

    try:
        # Load trained model
        predictor = CardiacRiskPredictor(model_path='models/cardiac_risk_model.pkl')
    except FileNotFoundError:
        print("Model not found. Please train the model first using option 2.")
        return

    # Create sample ECG signals
    print("Creating sample ECG signals...")

    # Normal signal
    t = np.linspace(0, 10, 3600)
    normal_signal = (np.sin(2 * np.pi * 1.25 * t) +
                    0.3 * np.sin(2 * np.pi * 0.5 * t) +
                    0.05 * np.random.randn(len(t)))

    # Abnormal signal (higher frequency, irregular)
    abnormal_signal = (np.sin(2 * np.pi * 2.0 * t) +
                      0.5 * np.sin(2 * np.pi * 0.3 * t) +
                      0.1 * np.random.randn(len(t)))

    signals = [normal_signal, abnormal_signal]
    signal_names = ["Normal ECG", "Abnormal ECG"]

    for signal, name in zip(signals, signal_names):
        print(f"\nAnalyzing {name}...")

        # Make prediction
        result, error = predictor.predict_from_signal(signal, sampling_rate=360)

        if result:
            print(f"Risk Score: {result['risk_score']}")
            print(f"Confidence: {result['confidence']:.2%}")
            print(f"Detected R-peaks: {result['qrs_info']['num_r_peaks']}")
            print(".1f")

            # Get interpretation
            interpretation = predictor.get_risk_interpretation(result['risk_score'], result['features'])
            print(f"Interpretation: {interpretation['interpretation']}")

            if interpretation['contributing_factors']:
                print("Contributing factors:")
                for factor in interpretation['contributing_factors']:
                    print(f"  - {factor}")

            # Visualize
            print("Generating visualization...")
            predictor.visualize_prediction(signal, result, sampling_rate=360)

        else:
            print(f"Prediction failed: {error}")

def demonstrate_explainability():
    """Demonstrate model explainability"""
    print("\nDemonstrating model explainability...")

    try:
        from model_training import CardiacRiskModel
        risk_model = CardiacRiskModel()
        risk_model.load_model('models/cardiac_risk_model.pkl')
    except FileNotFoundError:
        print("Model not found. Please train the model first.")
        return

    # Create sample features
    sample_features = pd.DataFrame({
        'heart_rate': [95],
        'rmssd': [15],
        'pnn50': [3],
        'lf_hf_ratio': [3.0],
        'qrs_amplitude': [0.6],
        'mean_rr': [0.65],
        'std_rr': [0.08],
        'qrs_energy': [80],
        'qrs_skewness': [0.2],
        'qrs_kurtosis': [0.5]
    })

    # Initialize explainability
    explainer = ECGExplainability(risk_model.model, risk_model.feature_columns)

    # Get feature contributions
    contributions = explainer.get_feature_contributions(sample_features.values[0])
    print("Top contributing features for this prediction:")
    for contrib in contributions:
        print(f"- {contrib['feature']}: {contrib['contribution']:.3f} ({contrib['direction']})")

    # Plot explanations
    print("Generating explanation plots...")
    explainer.plot_waterfall(sample_features.values[0])
    explainer.plot_force_plot(sample_features.values[0])

def run_full_pipeline():
    """Run the complete ECG analysis pipeline"""
    print("Running complete ECG analysis pipeline...")

    # Setup
    setup_project()

    # Train model
    model = train_model_pipeline()

    # Demonstrate prediction
    demonstrate_prediction()

    # Demonstrate explainability
    demonstrate_explainability()

    print("\nPipeline completed successfully!")
    print("Check the generated plots and results.")

def main():
    """Main application menu"""
    print("=" * 60)
    print("ECG-Based Cardiac Risk Score Prediction System")
    print("=" * 60)

    while True:
        print("\nAvailable options:")
        print("1. Setup project")
        print("2. Train cardiac risk model")
        print("3. Demonstrate risk prediction")
        print("4. Demonstrate explainability")
        print("5. Run full pipeline")
        print("6. Download MIT-BIH dataset info")
        print("7. Exit")

        try:
            choice = input("\nEnter your choice (1-7): ").strip()

            if choice == '1':
                setup_project()
            elif choice == '2':
                train_model_pipeline()
            elif choice == '3':
                demonstrate_prediction()
            elif choice == '4':
                demonstrate_explainability()
            elif choice == '5':
                run_full_pipeline()
            elif choice == '6':
                download_mit_bih_data()
            elif choice == '7':
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please try again.")

        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except Exception as e:
            print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
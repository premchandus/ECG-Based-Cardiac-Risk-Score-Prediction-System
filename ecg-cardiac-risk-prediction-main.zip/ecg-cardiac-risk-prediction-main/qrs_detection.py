import numpy as np
import matplotlib.pyplot as plt
from biosppy.signals import ecg
import pandas as pd
from scipy.signal import find_peaks

class QRSDetector:
    def __init__(self):
        pass

    def _fallback_peak_detection(self, signal, sampling_rate=360):
        """Fallback peak detection for short signals when biosppy is not suitable."""
        # Smooth the signal to reduce noise for short records
        if len(signal) > 3:
            smooth_signal = np.convolve(signal, np.ones(3) / 3, mode='same')
        else:
            smooth_signal = signal

        height = np.min(smooth_signal) + 0.25 * (np.max(smooth_signal) - np.min(smooth_signal))
        prominence = max(0.01, 0.1 * np.std(smooth_signal))
        distance = max(1, int(sampling_rate * 0.1))
        if distance >= len(signal):
            distance = 1

        peaks, _ = find_peaks(smooth_signal, height=height, prominence=prominence, distance=distance)

        if len(peaks) == 0:
            peaks = np.array([int(np.argmax(smooth_signal))])

        if len(peaks) > 1:
            rr_intervals = np.diff(peaks) / sampling_rate
            heart_rate = 60.0 / np.mean(rr_intervals) if np.mean(rr_intervals) > 0 else 0.0
        else:
            rr_intervals = np.array([])
            heart_rate = 75.0

        templates = []
        window = min(10, len(signal) // 2)
        for peak in peaks:
            start = max(0, peak - window)
            end = min(len(signal), peak + window + 1)
            template = signal[start:end]
            padded = np.pad(template, (0, max(0, 2 * window + 1 - len(template))), constant_values=0)
            templates.append(padded)

        templates = np.vstack(templates) if templates else None

        return {
            'r_peaks': peaks,
            'templates': templates,
            'heart_rate': heart_rate,
            'sampling_rate': sampling_rate
        }

    def detect_qrs(self, signal, sampling_rate=360):
        """Detect QRS complexes using biosppy or fallback peak detection for short signals."""
        try:
            min_samples = 5
            biosppy_min_samples = 400

            if len(signal) < min_samples:
                return None, f"Signal too short: {len(signal)} samples. Need at least {min_samples} samples"

            if np.std(signal) == 0:
                return None, "Signal has no variation (constant signal)"

            if len(signal) < biosppy_min_samples:
                return self._fallback_peak_detection(signal, sampling_rate)

            try:
                out = ecg.ecg(signal=signal, sampling_rate=sampling_rate, show=False)
                r_peaks = out['rpeaks']
                templates = out.get('templates', None)
                heart_rate = out['heart_rate']

                if len(r_peaks) == 0:
                    return self._fallback_peak_detection(signal, sampling_rate)

                return {
                    'r_peaks': r_peaks,
                    'templates': templates,
                    'heart_rate': heart_rate,
                    'sampling_rate': sampling_rate
                }
            except Exception:
                return self._fallback_peak_detection(signal, sampling_rate)
        except Exception as e:
            error_msg = f"QRS detection failed: {str(e)}"
            print(error_msg)
            return None, error_msg

    def calculate_rr_intervals(self, r_peaks, sampling_rate=360):
        """Calculate RR intervals in seconds"""
        rr_intervals = np.diff(r_peaks) / sampling_rate
        return rr_intervals

    def plot_qrs_detection(self, signal, r_peaks, sampling_rate=360):
        """Plot ECG signal with detected R-peaks"""
        time = np.arange(len(signal)) / sampling_rate

        plt.figure(figsize=(15, 6))
        plt.plot(time, signal, label='ECG Signal')

        # Mark R-peaks
        r_peak_times = r_peaks / sampling_rate
        r_peak_values = signal[r_peaks]
        plt.scatter(r_peak_times, r_peak_values, color='red', s=50, label='R-peaks', zorder=3)

        plt.xlabel('Time (s)')
        plt.ylabel('Amplitude')
        plt.title('ECG Signal with Detected R-peaks')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.show()

    def validate_qrs_detection(self, detected_peaks, annotated_peaks, tolerance=0.1, sampling_rate=360):
        """Validate QRS detection against annotations"""
        tolerance_samples = int(tolerance * sampling_rate)

        true_positives = 0
        false_positives = 0
        false_negatives = 0

        detected_set = set(detected_peaks)
        annotated_set = set(annotated_peaks)

        for detected in detected_peaks:
            if any(abs(detected - ann) <= tolerance_samples for ann in annotated_peaks):
                true_positives += 1
            else:
                false_positives += 1

        for ann in annotated_peaks:
            if not any(abs(ann - det) <= tolerance_samples for det in detected_peaks):
                false_negatives += 1

        precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
        recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
        f1_score = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        return {
            'precision': precision,
            'recall': recall,
            'f1_score': f1_score,
            'true_positives': true_positives,
            'false_positives': false_positives,
            'false_negatives': false_negatives
        }

if __name__ == "__main__":
    # Example usage
    detector = QRSDetector()

    # Dummy signal for testing
    t = np.linspace(0, 10, 3600)
    signal = np.sin(2 * np.pi * 1.25 * t) + 0.5 * np.sin(2 * np.pi * 0.5 * t)

    result = detector.detect_qrs(signal, sampling_rate=360)
    if result:
        print(f"Detected {len(result['r_peaks'])} R-peaks")
        print(f"Average heart rate: {np.mean(result['heart_rate']):.1f} BPM")

        rr_intervals = detector.calculate_rr_intervals(result['r_peaks'], sampling_rate=360)
        print(f"Average RR interval: {np.mean(rr_intervals):.3f} seconds")

        detector.plot_qrs_detection(signal, result['r_peaks'], sampling_rate=360)
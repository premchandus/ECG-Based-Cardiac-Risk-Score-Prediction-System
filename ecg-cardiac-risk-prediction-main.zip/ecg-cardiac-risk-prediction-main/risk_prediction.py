import numpy as np
import pandas as pd
from data_preprocessing import ECGDataPreprocessor
from qrs_detection import QRSDetector
from feature_extraction import ECGFeatureExtractor
from model_training import CardiacRiskModel
import matplotlib.pyplot as plt

class CardiacRiskPredictor:
    def __init__(self, model_path='models/cardiac_risk_model.pkl'):
        self.preprocessor = ECGDataPreprocessor()
        self.qrs_detector = QRSDetector()
        self.feature_extractor = ECGFeatureExtractor()
        self.risk_model = CardiacRiskModel()
        self.risk_model.load_model(model_path)

    def predict_from_signal(self, signal, sampling_rate=360):
        """Predict cardiac risk from raw ECG signal"""
        # Step 1: Preprocess signal
        filtered_signal = self.preprocessor.apply_bandpass_filter(signal, fs=sampling_rate)
        normalized_signal = self.preprocessor.normalize_signal(filtered_signal)

        # Step 2: Detect QRS complexes
        qrs_result = self.qrs_detector.detect_qrs(normalized_signal, sampling_rate)
        if qrs_result is None or isinstance(qrs_result, tuple):
            error_msg = qrs_result[1] if isinstance(qrs_result, tuple) else "QRS detection failed"
            return None, error_msg

        r_peaks = qrs_result['r_peaks']
        templates = qrs_result['templates']

        # Step 3: Calculate RR intervals
        rr_intervals = self.qrs_detector.calculate_rr_intervals(r_peaks, sampling_rate)

        # Step 4: Extract features
        features = self.feature_extractor.extract_all_features(rr_intervals, templates, sampling_rate)

        # Convert to DataFrame
        features_df = pd.DataFrame([features])

        # Step 5: Predict risk
        risk_labels, probabilities = self.risk_model.predict_risk(features_df)

        risk_score = risk_labels[0]
        confidence = float(np.max(probabilities[0]))
        
        # Convert numpy types to Python scalars for JSON serialization
        heart_rate_value = float(np.mean(qrs_result['heart_rate'])) if isinstance(qrs_result['heart_rate'], np.ndarray) else float(qrs_result['heart_rate'])
        
        # Convert all feature values to float
        features_serializable = {k: float(v) if isinstance(v, (np.ndarray, np.generic)) else v for k, v in features.items()}

        return {
            'risk_score': risk_score,
            'confidence': confidence,
            'probabilities': probabilities[0],
            'features': features_serializable,
            'qrs_info': {
                'num_r_peaks': len(r_peaks),
                'heart_rate': heart_rate_value
            },
            'rr_intervals': rr_intervals
        }, None

    def predict_from_record(self, record_data):
        """Predict cardiac risk from ECG record data"""
        processed = self.preprocessor.preprocess_record(record_data)
        return self.predict_from_signal(processed['normalized_signal'], processed['fs'])

    def get_risk_interpretation(self, risk_score, features):
        """Provide interpretation of the risk score"""
        interpretation = {
            'Low': "Low cardiac risk. Regular monitoring recommended.",
            'Medium': "Medium cardiac risk. Consult with healthcare provider for further evaluation.",
            'High': "High cardiac risk. Immediate medical attention recommended."
        }

        reasons = []

        if 'heart_rate' in features:
            hr = features['heart_rate']
            if hr < 60:
                reasons.append(f"Bradycardia detected (HR: {hr:.1f} BPM)")
            elif hr > 100:
                reasons.append(f"Tachycardia detected (HR: {hr:.1f} BPM)")

        if 'rmssd' in features and features['rmssd'] < 20:
            reasons.append(f"Low heart rate variability (RMSSD: {features['rmssd']:.2f} ms)")

        if 'pnn50' in features and features['pnn50'] < 5:
            reasons.append(f"Low heart rate variability (pNN50: {features['pnn50']:.2f}%)")

        if 'lf_hf_ratio' in features:
            ratio = features['lf_hf_ratio']
            if ratio > 2.5:
                reasons.append(f"High sympathetic activity (LF/HF: {ratio:.2f})")
            elif ratio < 0.5:
                reasons.append(f"High parasympathetic activity (LF/HF: {ratio:.2f})")

        return {
            'interpretation': interpretation.get(risk_score, "Unable to determine risk level"),
            'contributing_factors': reasons
        }

    def visualize_prediction(self, signal, prediction_result, sampling_rate=360):
        """Visualize the prediction results"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))

        # Plot 1: ECG signal
        time = np.arange(len(signal)) / sampling_rate
        axes[0, 0].plot(time, signal)
        axes[0, 0].set_title('ECG Signal')
        axes[0, 0].set_xlabel('Time (s)')
        axes[0, 0].set_ylabel('Amplitude')
        axes[0, 0].grid(True, alpha=0.3)

        # Plot 2: Risk probabilities
        risk_levels = self.risk_model.label_encoder.classes_
        probabilities = prediction_result['probabilities']
        axes[0, 1].bar(risk_levels, probabilities, color=['green', 'orange', 'red'])
        axes[0, 1].set_title(f'Risk Prediction Probabilities\nPredicted: {prediction_result["risk_score"]} ({prediction_result["confidence"]:.2%})')
        axes[0, 1].set_ylabel('Probability')

        # Plot 3: Key features
        features_to_plot = ['heart_rate', 'rmssd', 'pnn50', 'lf_hf_ratio']
        feature_values = [prediction_result['features'].get(f, 0) for f in features_to_plot]
        axes[1, 0].bar(features_to_plot, feature_values, color='skyblue')
        axes[1, 0].set_title('Key ECG Features')
        axes[1, 0].set_ylabel('Value')
        axes[1, 0].tick_params(axis='x', rotation=45)

        # Plot 4: RR intervals
        if 'rr_intervals' in prediction_result:
            rr_intervals = prediction_result['rr_intervals']
            axes[1, 1].plot(rr_intervals, 'o-')
            axes[1, 1].set_title('RR Intervals')
            axes[1, 1].set_xlabel('Beat number')
            axes[1, 1].set_ylabel('RR Interval (s)')
            axes[1, 1].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def batch_predict(self, signals_list, sampling_rates=None):
        """Predict risk for multiple signals"""
        if sampling_rates is None:
            sampling_rates = [360] * len(signals_list)

        results = []
        for signal, fs in zip(signals_list, sampling_rates):
            result, error = self.predict_from_signal(signal, fs)
            if result:
                results.append(result)
            else:
                results.append({'error': error})

        return results

if __name__ == "__main__":
    # Example usage
    predictor = CardiacRiskPredictor()

    # Create a synthetic ECG signal
    np.random.seed(42)
    t = np.linspace(0, 10, 3600)
    signal = (np.sin(2 * np.pi * 1.25 * t) +
              0.5 * np.sin(2 * np.pi * 0.5 * t) +
              0.1 * np.random.randn(len(t)))

    # Make prediction
    result, error = predictor.predict_from_signal(signal, sampling_rate=360)

    if result:
        print(f"Predicted Risk Score: {result['risk_score']}")
        print(f"Confidence: {result['confidence']:.2%}")
        print(f"Number of R-peaks detected: {result['qrs_info']['num_r_peaks']}")
        print(f"Average Heart Rate: {np.mean(result['qrs_info']['heart_rate']):.1f} BPM")

        # Get interpretation
        interpretation = predictor.get_risk_interpretation(result['risk_score'], result['features'])
        print(f"\nInterpretation: {interpretation['interpretation']}")
        if interpretation['contributing_factors']:
            print("Contributing factors:")
            for factor in interpretation['contributing_factors']:
                print(f"- {factor}")

        # Visualize
        predictor.visualize_prediction(signal, result, sampling_rate=360)
    else:
        print(f"Prediction failed: {error}")